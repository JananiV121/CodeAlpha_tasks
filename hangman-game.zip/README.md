# Hangman Game – CodeAlpha Internship Task

This is a simple text-based Hangman game written in Python. It was developed as part of the CodeAlpha Internship (Task 1: Python Programming).

## Features

- Random word selection
- ASCII-art based hangman display
- Guessed letter tracking
- Limited lives system
- Input validation for better user experience

## How to Run

1. Make sure Python 3 is installed.
2. Extract the ZIP.
3. Open terminal in the project directory.
4. Run the game with:

```bash
python hangman.py
```

## Author

Submitted by [Your Name] for CodeAlpha Internship.
