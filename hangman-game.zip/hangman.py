import random

stages = [
    """
     -----
     |   |
     O   |
    /|\  |
    / \  |
        ===
    """,
    """
     -----
     |   |
     O   |
    /|\  |
    /    |
        ===
    """,
    """
     -----
     |   |
     O   |
    /|\  |
         |
        ===
    """,
    """
     -----
     |   |
     O   |
    /|   |
         |
        ===
    """,
    """
     -----
     |   |
     O   |
     |   |
         |
        ===
    """,
    """
     -----
     |   |
     O   |
         |
         |
        ===
    """,
    """
     -----
     |   |
         |
         |
         |
        ===
    """
]

words = ["python", "hangman", "challenge", "developer", "codealpha", "function", "keyboard"]
word = random.choice(words)
word_letters = list(word)
guessed = ['_'] * len(word)
guessed_letters = []
lives = 6

print("Welcome to Hangman Game!")
print("Guess the word below:\n")

while lives > 0 and '_' in guessed:
    print("Word: ", " ".join(guessed))
    print("Guessed letters:", ", ".join(guessed_letters))
    print(stages[6 - lives])
    
    guess = input("Enter a letter: ").lower()

    if not guess.isalpha() or len(guess) != 1:
        print("Please enter a single alphabet letter.\n")
        continue

    if guess in guessed_letters:
        print("You already guessed that letter.\n")
        continue

    guessed_letters.append(guess)

    if guess in word_letters:
        for i in range(len(word)):
            if word[i] == guess:
                guessed[i] = guess
        print("Good guess!\n")
    else:
        lives -= 1
        print(f"Wrong guess! You lost a life. Lives remaining: {lives}\n")

if '_' not in guessed:
    print("Congratulations! You guessed the word:", word)
else:
    print(stages[6 - lives])
    print("Game Over! The word was:", word)
