import random

def basic_chatbot():
    responses = {
        "hi": ["Hello!", "Hi there!", "Hey!"],
        "how are you": ["I'm doing well, thanks!", "All good! How about you?"],
        "what is your name": ["I'm a simple chatbot.", "You can call me ChatBuddy."],
        "bye": ["Goodbye!", "See you later!", "Bye! Have a nice day!"]
    }

    print("Welcome to the Basic Chatbot! Type 'bye' to exit.")
    while True:
        user_input = input("You: ").lower().strip()
        if user_input == "bye":
            print("Bot:", random.choice(responses["bye"]))
            break
        found = False
        for key in responses:
            if key in user_input:
                print("Bot:", random.choice(responses[key]))
                found = True
                break
        if not found:
            print("Bot: Sorry, I didn't understand that.")

if __name__ == "__main__":
    basic_chatbot()
