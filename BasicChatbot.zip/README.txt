Basic Chatbot - Internship Task 3

Description:
-------------
A simple text-based chatbot created using Python. This bot can respond to basic conversational phrases like greetings and questions.

Features:
- Greets users
- Responds to questions like "how are you", "what is your name"
- Ends conversation when user says "bye"

How to Run:
-------------
1. Make sure Python is installed on your system.
2. Open a terminal in this folder.
3. Run the following command:
   python main.py

No additional libraries are required.
