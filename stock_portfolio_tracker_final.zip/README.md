# Stock Portfolio Tracker

This is a simple command-line Stock Portfolio Tracker built with Python.

## Features
- Add and remove stocks from your portfolio
- View real-time stock prices
- Calculate total portfolio value
- Save/load portfolio data from a JSON file

## Requirements
- Python 3.x
- yfinance

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the program:
   ```bash
   python main.py
   ```

## Files
- `main.py`: Main application code
- `portfolio.json`: Stores your portfolio data
- `requirements.txt`: Python package requirements

## License
This project is open-source and free to use.
