import yfinance as yf
import json
import os

PORTFOLIO_FILE = 'portfolio.json'

def load_portfolio():
    if os.path.exists(PORTFOLIO_FILE):
        with open(PORTFOLIO_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_portfolio(portfolio):
    with open(PORTFOLIO_FILE, 'w') as f:
        json.dump(portfolio, f, indent=4)

def add_stock(portfolio):
    symbol = input("Enter stock symbol: ").upper()
    quantity = int(input("Enter quantity: "))
    if symbol in portfolio:
        portfolio[symbol]['quantity'] += quantity
    else:
        portfolio[symbol] = {'quantity': quantity}
    print(f"Added {quantity} shares of {symbol}.")

def remove_stock(portfolio):
    symbol = input("Enter stock symbol to remove: ").upper()
    if symbol in portfolio:
        del portfolio[symbol]
        print(f"Removed {symbol} from portfolio.")
    else:
        print("Stock not found in portfolio.")

def view_portfolio(portfolio):
    print("\n--- Portfolio ---")
    total_value = 0
    for symbol, data in portfolio.items():
        stock = yf.Ticker(symbol)
        current_price = stock.info.get('regularMarketPrice', 0)
        value = current_price * data['quantity']
        print(f"{symbol}: {data['quantity']} shares @ ${current_price:.2f} = ${value:.2f}")
        total_value += value
    print(f"Total Portfolio Value: ${total_value:.2f}\n")

def main():
    portfolio = load_portfolio()
    while True:
        print("1. View Portfolio\n2. Add Stock\n3. Remove Stock\n4. Save & Exit")
        choice = input("Choose an option: ")
        if choice == '1':
            view_portfolio(portfolio)
        elif choice == '2':
            add_stock(portfolio)
        elif choice == '3':
            remove_stock(portfolio)
        elif choice == '4':
            save_portfolio(portfolio)
            print("Portfolio saved. Exiting...")
            break
        else:
            print("Invalid option. Try again.")

if __name__ == "__main__":
    main()
